# MinecraftCapesBot
The Minecraft Capes Discord Bot.

Usage:
Download all the source code on the "Code" page and run `npm i` inside of the MinecraftCapesBot folder.
You may edit the code of the bot to your liking.
Before using the bot, make sure to make a `config.json` inside of the MinecraftCapesBot folder. Then run `npm start` to use nodemon, or use `npm startdev` to use node.

```
use "!commands" for list of commands when bot is running.
```

![cool image](https://cdn.discordapp.com/attachments/433816025343983618/717421281149976716/Screen_Shot_2020-06-02_at_9.55.59_AM.png)

## Credits
* james090500 (For Existing)
* Siriuo (For creating the bot)
* Ktg5 (For improving some stuff)
